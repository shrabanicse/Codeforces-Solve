#include <stdio.h>
#include <string.h>
int main()
{
    int n, t;
    scanf("%d %d", &n, &t);
    char queue[n + 1];
    scanf("%s", queue);
    for (int i = 0; i < t; i++)
    {
        for (int j = 0; j < n - 1; j++)
        {
            if (queue[j] == 'B' && queue[j + 1] == 'G')
            {
                queue[j] = 'G';
                queue[j + 1] = 'B';
                j++;
            }
        }
    }
    printf("%s\n", queue);
    return 0;
}
