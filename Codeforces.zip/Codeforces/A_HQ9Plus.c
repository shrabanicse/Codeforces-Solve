#include <stdio.h>
#include <string.h>
int main()
{
    char instructions[101];
    scanf("%s", instructions);
    int result = 0;
    int len = strlen(instructions);
    for (int i = 0; i < len; i++)
    {
        char instruction = instructions[i];
        if (instruction == 'H' || instruction == 'Q' || instruction == '9')
        {
            result = 1;
            break;
        }
    }
    if (result)
    {
        printf("YES\n");
    }
    else
    {
        printf("NO\n");
    }
    return 0;
}
