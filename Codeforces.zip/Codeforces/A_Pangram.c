#include <stdio.h>
#include <ctype.h>
int main()
{
    int n;
    scanf("%d", &n);
    char str[101];
    scanf("%s", str);
    int present[26] = {0};
    for (int i = 0; str[i] != '\0'; i++)
    {
        char ch = tolower(str[i]);
        present[ch - 'a'] = 1;
    }
    int pangram = 1;
    for (int i = 0; i < 26; i++)
    {
        if (present[i] == 0)
        {
            pangram = 0;
            break;
        }
    }
    if (pangram)
    {
        printf("YES\n");
    }
    else
    {
        printf("NO\n");
    }
    return 0;
}
