#include <bits/stdc++.h>
using namespace std;

int main()
{
    int up = 0, low = 0;
    string s;
    cin >> s;

    for (int i = 0; i < s.size(); i++)
    {
        if (isupper(s[i]))
        {
            up++;
        }
        else
        {
            low++;
        }
    }

    if (up > low)
    {
        for (int i = 0; i < s.size(); i++)
        {
            cout << char(toupper(s[i]));
        }
    }
    else
    {
        for (int i = 0; i < s.size(); i++)
        {
            cout << char(tolower(s[i]));
        }
    }

    return 0;
}
