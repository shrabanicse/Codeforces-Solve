#include <stdio.h>
int main()
{
    int n,cur_p = 0,max_cap = 0;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        int exit, enter;
        scanf("%d %d", &exit, &enter);
        cur_p -= exit;
        cur_p += enter;
        if (cur_p > max_cap)
        {
            max_cap = cur_p;
        }
    }
    printf("%d\n", max_cap);
    return 0;
}
