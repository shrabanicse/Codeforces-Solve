#include <stdio.h>
int main()
{
    int colors[4];
    scanf("%d %d %d %d", &colors[0], &colors[1], &colors[2], &colors[3]);
    int distinct_colors = 0;
    for (int i = 0; i < 4; ++i)
    {
        for (int j = i + 1; j < 4; ++j)
        {
            if (colors[i] == colors[j])
            {
                distinct_colors++;
                break;
            }
        }
    }
    printf("%d\n", distinct_colors);
    return 0;
}
