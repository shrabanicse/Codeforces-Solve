#include <stdio.h>
int main()
{
    int n,opinion,is_hard = 0;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &opinion);
        if (opinion == 1)
        {
            is_hard = 1;
        }
    }
    if (is_hard)
    {
        printf("HARD\n");
    }
    else
    {
        printf("EASY\n");
    }
    return 0;
}

