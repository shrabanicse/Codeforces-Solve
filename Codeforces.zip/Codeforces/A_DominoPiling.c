#include<stdio.h>
int main()
{
    int m,n;
    scanf("%d %d", &m, &n);
    int x=(m*n)/2;
    printf("%d", x);
    return 0;
}
