#include <stdio.h>
int main()
{
    int n, h, height, total_width = 0;
    scanf("%d %d", &n, &h);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &height);
        if (height > h)
        {
            total_width += 2;
        }
        else
        {
            total_width += 1;
        }
    }
    printf("%d\n", total_width);
    return 0;
}

