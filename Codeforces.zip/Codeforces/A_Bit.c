#include <stdio.h>
#include <string.h>
int main()
{
    int n,count=0;
    char arr[4];
    scanf("%d",&n);

    for(int i=0; i<n; i++)
    {
        scanf("%s",&arr);
        if(arr[0]=='+' || arr[1]=='+')
        {
            count++;
        }
        else
        {
            count--;
        }
    }
    printf("%d",count);
    return 0;
}

