#include <stdio.h>
int main()
{
    long long n, k, even_count, odd_count;
    scanf("%lld %lld", &n, &k);
    if (n % 2 == 0)
    {
        even_count = n / 2;
        odd_count = n / 2;
    }
    else
    {
        even_count = n / 2;
        odd_count = n / 2 + 1;
    }
    if (k <= odd_count)
    {
        printf("%lld\n", 1 + (k - 1) * 2);
    }
    else
    {
        printf("%lld\n", 2 + (k - odd_count - 1) * 2);
    }
    return 0;
}

