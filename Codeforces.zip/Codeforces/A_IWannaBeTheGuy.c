#include <stdio.h>
int main()
{
    int n;
    scanf("%d", &n);
    int levels[n];
    for (int i = 0; i < n; i++)
    {
        levels[i] = 0;
    }
    int p, q;
    scanf("%d", &p);
    for (int i = 0; i < p; i++)
    {
        int level;
        scanf("%d", &level);
        levels[level - 1] = 1;
    }
    scanf("%d", &q);
    for (int i = 0; i < q; i++)
    {
        int level;
        scanf("%d", &level);
        levels[level - 1] = 1;
    }
    int canPassAll = 1;
    for (int i = 0; i < n; i++)
    {
        if (levels[i] == 0)
        {
            canPassAll = 0;
            break;
        }
    }
    if (canPassAll)
    {
        printf("I become the guy.\n");
    }
    else
    {
        printf("Oh, my keyboard!\n");
    }
    return 0;
}
