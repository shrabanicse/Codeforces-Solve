#include <stdio.h>
#include <string.h>
int main()
{
    int n,anton_wins = 0,danik_wins = 0;
    scanf("%d", &n);
    char games[n + 1];
    scanf("%s", games);
    for (int i = 0; i < n; i++)
    {
        if (games[i] == 'A')
        {
            anton_wins++;
        }
        else if (games[i] == 'D')
        {
            danik_wins++;
        }
    }
    if (anton_wins > danik_wins)
    {
        printf("Anton\n");
    }
    else if (danik_wins > anton_wins)
    {
        printf("Danik\n");
    }
    else
    {
        printf("Friendship\n");
    }
    return 0;
}
