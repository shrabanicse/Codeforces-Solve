#include <stdio.h>
int main()
{
    int n;
    scanf("%d", &n);
    int h[n], max = 0, min = 101, max_i = 0, min_i = 0;
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &h[i]);
        if (h[i] > max)
        {
            max = h[i];
            max_i = i;
        }
        if (h[i] <= min)
        {
            min = h[i];
            min_i = i;
        }
    }
    int ops = max_i + (n - 1 - min_i);
    if (max_i > min_i) ops--;
    printf("%d\n", ops);
    return 0;
}
