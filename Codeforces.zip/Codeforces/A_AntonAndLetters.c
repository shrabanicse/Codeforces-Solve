#include <stdio.h>
#include <stdbool.h>
int main()
{
    bool present[26] = { false };
    char ch;
    while (scanf("%c", &ch) == 1 && ch != '\n')
    {
        if ('a' <= ch && ch <= 'z')
        {
            present[ch - 'a'] = true;
        }
    }
    int count = 0;
    for (int i = 0; i < 26; i++)
    {
        if (present[i])
        {
            count++;
        }
    }
    printf("%d\n", count);
    return 0;
}
