#include<stdio.h>
//#include<math.h>
int main()
{
    int f, result;
    scanf("%d", &f);
    if(f%5 == 0)
    {
        result= f/5;
    }
    else
    {
        result= f/5 +1;
    }
    printf("%d", result);
    return 0;
}
