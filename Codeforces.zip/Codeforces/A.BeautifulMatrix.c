#include<stdio.h>
#include<math.h>
int main()
{
    int arr [5][5],m,n;
    for(int i=0; i<5; i++)
    {
        for (int j=0; j<5; j++)
        {
            scanf("%d", &arr[i][j]);
        }
    }
    for(int i=0; i<5; i++)
    {
        for (int j=0; j<5; j++)
        {
            if(arr[i][j]==1)
            {
                m=i;
                n=j;
            }
        }
    }
    int row= abs(m-2);
    int col= abs(n-2);
    printf("%d", row+col);
    return 0;
}
