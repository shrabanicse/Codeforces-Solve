#include<bits/stdc++.h>
using namespace std;
int main()
{
    string s, f = "";
    cin >> s;
    for (int i=0; i<s.size(); i++)
    {
        char vow = tolower(s[i]);
        if (vow == 'a' || vow == 'e' || vow == 'i' ||  vow == 'o' || vow == 'u' || vow == 'y')
        {
            continue;
        }
        else
        {
            f += ".";
            f += vow;
        }
    }
    cout << f << endl;
    return 0;
}
