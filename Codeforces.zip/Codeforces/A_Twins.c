#include <stdio.h>
#include <stdlib.h>
int compare(const void *a, const void *b)
{
    return (*(int *)b - *(int *)a);
}
int main()
{
    int n;
    scanf("%d", &n);
    int coins[n];
    int total_sum = 0;
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &coins[i]);
        total_sum += coins[i];
    }
    qsort(coins, n, sizeof(int), compare);
    int alex_sum = 0, alex_coins = 0;
    for (int i = 0; i < n; i++)
    {
        alex_sum += coins[i];
        alex_coins++;
        if (alex_sum > total_sum / 2)
        {
            break;
        }
    }
    printf("%d\n", alex_coins);
    return 0;
}
