#include <stdio.h>

int main()
{
    char a[100], b[100];
    int i, j = 0;
    gets(a);
    for (i = 0; a[i] != '\0'; i++)
    {
        if (a[i] == '1' || a[i] == '2' || a[i] == '3')
        {
            b[j] = a[i];
            j++;
        }
    }
    b[j] = '\0';
    for (i = 0; i < j - 1; i++)
    {
        for (int k = 0; k < j - 1 - i; k++)
        {
            if (b[k] > b[k + 1])
            {
                char temp = b[k];
                b[k] = b[k + 1];
                b[k + 1] = temp;
            }
        }
    }
    for (i = 0; i < j; i++)
    {
        if (i > 0)
        {
            printf("+");
        }
        printf("%c", b[i]);
    }

    return 0;
}
