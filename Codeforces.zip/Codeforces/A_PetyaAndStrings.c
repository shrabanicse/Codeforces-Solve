#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main()
{
    char f[1001], s[1001];
    while (scanf("%s %s", f, s) != EOF)
    {
        long long i;

        // Convert both strings to lowercase
        for (i = 0; i < strlen(f); i++)
        {
            if (f[i] >= 'A' && f[i] <= 'Z')
                f[i] = f[i] - 'A' + 'a';

            if (s[i] >= 'A' && s[i] <= 'Z')
                s[i] = s[i] - 'A' + 'a';
        }

        // Compare the strings
        for (i = 0; i < strlen(s); i++)
        {
            if (f[i] > s[i])
            {
                printf("1\n");
                return 0;
            }
            if (s[i] > f[i])
            {
                printf("-1\n");
                return 0;
            }
        }
        printf("0\n");
    }
    return 0;
}
