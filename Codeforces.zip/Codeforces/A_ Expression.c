#include <stdio.h>
int main()
{
    int a, b, c;
    scanf("%d %d %d", &a, &b, &c);
    int max_value = a + b + c;
    if (a * (b + c) > max_value) max_value = a * (b + c);
    if ((a + b) * c > max_value) max_value = (a + b) * c;
    if (a * b * c > max_value) max_value = a * b * c;
    printf("%d\n", max_value);
    return 0;
}

