#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int main()
{
    int n,total_sum = 0;
    cin >> n;
    vector<int> coins(n);
    for (int i = 0; i < n; ++i)
    {
        cin >> coins[i];
        total_sum += coins[i];
    }
    sort(coins.rbegin(), coins.rend());
    int alex_sum = 0, alex_coins = 0;
    for (int i = 0; i < n; ++i)
    {
        alex_sum += coins[i];
        alex_coins++;
        if (alex_sum > total_sum / 2)
        {
            break;
        }
    }
    cout << alex_coins << endl;
    return 0;
}
