#include <stdio.h>
int main()
{
    int n,x,y,z,x_sum = 0,y_sum = 0,z_sum = 0;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d %d %d", &x, &y, &z);
        x_sum += x;
        y_sum += y;
        z_sum += z;
    }
    if (x_sum == 0 && y_sum == 0 && z_sum == 0)
    {
        printf("YES\n");
    }
    else
    {
        printf("NO\n");
    }
    return 0;
}

