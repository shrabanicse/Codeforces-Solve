#include <stdio.h>
int main()
{
    int n;
    scanf("%d", &n);
    int p[n+1];
    for (int i = 1; i <= n; i++)
    {
        int pi;
        scanf("%d", &pi);
        p[pi] = i;
    }
    for (int i = 1; i <= n; i++)
    {
        printf("%d ", p[i]);
    }
    printf("\n");
    return 0;
}
