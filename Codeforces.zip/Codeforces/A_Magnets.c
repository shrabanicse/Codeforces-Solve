#include <stdio.h>
int main()
{
    int n,i,groups = 0;
    scanf("%d", &n);
    char current[3];
    char next[3];
    scanf("%s", current);
    groups = 1;
    for (i = 1; i < n; i++)
    {
        scanf("%s", next);
        if (next[0] == current[1])
        {
            groups++;
        }
        current[0] = next[0];
        current[1] = next[1];
    }
    printf("%d\n", groups);
    return 0;
}

