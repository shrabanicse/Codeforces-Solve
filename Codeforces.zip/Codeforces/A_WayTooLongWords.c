#include <stdio.h>
#include <string.h>
int main()
{
    int i, f;
    char n[100];
    scanf("%d", &f);
    for (i=0; i<f; i++)
    {
        scanf("%s", &n);
        int s = strlen(n);
        {
            if (s>10)
            {
                printf("%c%d%c\n", n[0], s-2, n[s-1]);
            }
            else
                printf("%s\n", n);
        }
    }
    return 0;
}
