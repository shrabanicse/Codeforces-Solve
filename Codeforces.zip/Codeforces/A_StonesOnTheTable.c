#include<stdio.h>
int main()
{
    int f, i, count=0;
    char string[100];
    scanf("%d", &f);
    scanf("%s", string);
    for (i=0; i<f-1; i++)
    {
        if(string[i] == string[i+1])
            count++;
    }
    printf("%d", count);
    return 0;
}
