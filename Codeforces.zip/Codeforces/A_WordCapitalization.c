#include<stdio.h>
int main()
{
    char arr[1001];
    scanf("%s", &arr);
    if((arr[0]>='a')&&(arr[0]<='z'))
            arr[0]=arr[0]-32;
            printf("%s", arr);
            return 0;
}
