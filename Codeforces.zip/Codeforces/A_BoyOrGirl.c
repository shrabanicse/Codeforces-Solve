#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main()
{
    int i, j, len, t = 0, c = 0, count[26] = {0};
    char s[100] = {'0'};
    while (scanf("%s", s) == 1)
    {
        t = 0;
        len = strlen(s);
        c = 0;
        for (i = 0; i < len; i++)
        {
            t = s[i] - 97;
            count[t]++;
        }
        for (j = 0; j < 26; j++)
        {
            if (count[j] >= 1)
            {
                c++;
            }
        }
        if (c % 2 == 0)
        {
            printf("CHAT WITH HER!\n");
        }
        else
        {
            printf("IGNORE HIM!\n");
        }
        memset(s, '0', sizeof s);
        memset(count, 0, sizeof count);
    }
    return 0;
}
