#include<stdio.h>
int main()
{
    int n, k, a, count = 0;
    int arr[10000];
    scanf("%d %d",&n,&k);//n= Total participants, k= kth participant's score
    for (int i=0; i<n; i++)
    {
        scanf("%d",&a);
        arr[i] = a;
    }
    for (int j=0; j<n; j++)
    {
        if (arr[j]>=arr[k-1] && arr[j]>0)
        {
            count++;
        }
    }
    printf("%d",count);
    return 0;
}
